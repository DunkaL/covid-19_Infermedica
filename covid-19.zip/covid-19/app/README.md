# covid-19_Infermedica

https://dunkal.github.io/covid-19_Infermedica/

covid-19 (sass, gulp, wow.js)
